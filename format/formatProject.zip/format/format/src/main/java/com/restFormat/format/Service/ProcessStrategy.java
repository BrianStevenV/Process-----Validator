package com.restFormat.format.Service;

import java.util.Map;

public interface ProcessStrategy {

    void process();
    boolean lineValidate(String line, String fileType, Map<String, String> requestBody);
}
