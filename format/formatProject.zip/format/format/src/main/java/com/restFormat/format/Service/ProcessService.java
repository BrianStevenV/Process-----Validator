package com.restFormat.format.Service;

import org.springframework.stereotype.Service;

@Service
public class ProcessService {
    //Missing other type of validation to choose if csv or xlsx.
    private FileName filePath;


    public void typeFormat(FileName filePath){
        if(filePath.getFilePath().contains(".csv")){
            ProcessCSV processCSV = new ProcessCSV(filePath);
            processCSV.process();
        } else if (filePath.getFilePath().contains(".xlsx")) {
            ProcessXSLX processXSLX = new ProcessXSLX(filePath);
            processXSLX.process();
        }
    }
}
