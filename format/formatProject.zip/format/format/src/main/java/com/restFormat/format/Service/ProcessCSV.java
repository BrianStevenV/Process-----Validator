package com.restFormat.format.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestTemplate;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.HashMap;
import java.util.StringTokenizer;

import java.util.Map;

public class ProcessCSV implements ProcessStrategy{
    private FileName filePath;
    private String delimeter = ",";
    public ProcessCSV(FileName filePath){
        this.filePath = filePath;
    }

    @Override
    public void process() {
        Map<String, String> requestBody = new HashMap<>();
        requestBody.put("fileType", filePath.getFileType());
        try (BufferedReader br = new BufferedReader(new FileReader(filePath.getFilePath()))) {
            String line;
            while ((line = br.readLine()) != null) {
                StringTokenizer tokenizer = new StringTokenizer(line, delimeter);
                while (tokenizer.hasMoreTokens()) {
                    String field = tokenizer.nextToken();
                    boolean response = lineValidate(field.toString(), filePath.getFileType(), requestBody);
                    System.out.print(field + "\t");
                }
                System.out.println();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
//    @Override
//    public boolean lineValidate(String line){
//        RestTemplate restTemplate = new RestTemplate();
//        HttpHeaders headers = new HttpHeaders();
//        headers.setContentType(MediaType.APPLICATION_JSON);
//        HttpEntity<String> request = new HttpEntity<>(line, headers);
//        boolean response = restTemplate.postForObject("http://localhost:8090/validator/lines", request, Boolean.class);
//        return response;
//    }

    @Override
    public boolean lineValidate(String line, String fileType, Map<String, String> requestBody){
        requestBody.put("line", line);
        requestBody.put("fileType", fileType);
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Map<String, String>> request = new HttpEntity<>(requestBody, headers);
        boolean response = restTemplate.postForObject("http://localhost:8090/api/v1/validator/lines", request, Boolean.class);
        return response;
    }
}


