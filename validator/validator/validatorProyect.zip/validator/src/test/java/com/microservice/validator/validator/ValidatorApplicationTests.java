package com.microservice.validator.validator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ValidatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
