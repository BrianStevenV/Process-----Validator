package com.microservice.validator.validator.Service;

import com.microservice.validator.validator.Data.fileXSLX;

public class ValidationXSLX implements ValidatorStrategy{
    private fileXSLX fileXSLX;

    private int lineValid;
    private int lineInvalid;

    public ValidationXSLX(fileXSLX fileXSLX) {
        this.fileXSLX = fileXSLX;
    }


    @Override
    public boolean validation() {
        if(fileXSLX.getInjuryLocation()!="N/A" || (fileXSLX.getReportType().equals("(Near Miss") || fileXSLX.getReportType().equals("Lost Time") || fileXSLX.getReportType().equals("First Aid"))){
            lineValid++;
            return true;
        }
        lineInvalid++;
        return false;
    }

    public String printLines(){
        String lineValidString = String.valueOf((int) (lineValid));
        String lineInvalidateString = String.valueOf((int) (lineInvalid));
        return "Line valid: " + lineValidString + " " + "Line invalid: " + lineInvalidateString;
    }

    public int getLineValid() {
        return lineValid;
    }

    public void setLineValid(int lineValid) {
        this.lineValid = lineValid;
    }

    public int getLineInvalid() {
        return lineInvalid;
    }

    public void setLineInvalid(int lineInvalid) {
        this.lineInvalid = lineInvalid;
    }
}
