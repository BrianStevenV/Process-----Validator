package com.microservice.validator.validator.Service;

public interface ValidatorStrategy {
    boolean validation();
}
