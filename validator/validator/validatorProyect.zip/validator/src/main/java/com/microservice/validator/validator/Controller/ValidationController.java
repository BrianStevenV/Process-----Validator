package com.microservice.validator.validator.Controller;

import com.microservice.validator.validator.Data.FileName;
import com.microservice.validator.validator.Service.ValidationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;



@RestController
@RequestMapping("/validator")
public class ValidationController {
    @Autowired
    private ValidationService validationService;

    @PostMapping("/lines")
    public void processValidationArchives(@RequestBody FileName fileName){
        validationService.validateFile(fileName);
    }


}
