package com.microservice.validator.validator.Service;

import com.microservice.validator.validator.Data.fileXSLX;
import com.microservice.validator.validator.Data.fileCSV;
import com.microservice.validator.validator.Data.FileName;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.Scanner;

@Service
public class ValidationService {

    private String lineArchive;

    private String typeArchive;
    public ResponseEntity<String> validateFile(@RequestBody FileName fileName) {
        String fileType = fileName.getFileType();
        if ("CSV".equals(fileType)) {
            Scanner scanner = new Scanner(lineArchive);
            fileCSV fileCSV = new fileCSV(scanner.next(), scanner.next(), scanner.next(), scanner.next(), scanner.next(), scanner.next(), scanner.next(), scanner.next(), scanner.next());
            ValidationCSV validationCSV = new ValidationCSV(fileCSV);
            validationCSV.validation();
            return ResponseEntity.ok("Validation of archive CSV succesfull!");
        } else if ("XSLX".equals(fileType)) {
            Scanner scanner = new Scanner(lineArchive);
            fileXSLX fileXSLX = new fileXSLX(scanner.next(), scanner.next(), scanner.next(), scanner.next(), scanner.next(), scanner.next(), scanner.next(), scanner.next(), scanner.next(), scanner.next(), scanner.next(), scanner.next(), scanner.next(), scanner.next());
            ValidationXSLX validationXSLX = new ValidationXSLX(fileXSLX);
            validationXSLX.validation();
            return ResponseEntity.ok("Validation of archive XSLX succesfull!");
        } else {
            return ResponseEntity.badRequest().body("Error, Unknown archive.");
        }
    }
}
